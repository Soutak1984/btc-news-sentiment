# BTC News Sentiment - SQLite + Python One Click

This edition removes the MySQL dependency.

## Requirements

Only:

- Python 3.x
- PHP 8+
- PHP extensions:
  - PDO SQLite
  - cURL
  - SimpleXML
  - mbstring

No MySQL server is required.

## Windows

Double-click:

`start_windows.bat`

The launcher will:

1. Find PHP.
2. Start PHP's built-in web server.
3. Use SQLite automatically.
4. Open the browser.
5. Collect BTC news.
6. Calculate sentiment.

Dashboard:

`http://127.0.0.1:8080`

If 8080 is occupied, another port is selected automatically.

## Database

The SQLite file is created automatically:

`data/btc_sentiment.sqlite`

There is no username/password configuration.

## Linux/macOS

```bash
python3 run.py
```

## Troubleshooting

Open these URLs in the browser:

```text
/api/status.php
/api/refresh.php
/api/news.php
/api/sentiment.php
```

The dashboard also displays PHP, SQLite, cURL, SimpleXML, news and BTC API status.

## News sources

The initial version uses Google News RSS searches for:

- Bitcoin
- Bitcoin ETF
- Bitcoin regulation
- Bitcoin institutional
- Bitcoin whale

The feed configuration is in `config.php`.

## Important

The sentiment score is a rule-based news indicator. It is not a standalone trading signal.

For a trading-oriented version, combine news sentiment with BTC price, volume, funding, open interest, liquidations and options data.
