<?php
require_once __DIR__ . '/news_fetcher.php';
require_once __DIR__ . '/sentiment.php';

try {
    $pdo = db();

    $fetch = fetch_and_store_news($pdo);

    $s1 = aggregate_sentiment($pdo, 1);
    $s6 = aggregate_sentiment($pdo, 6);
    $s24 = aggregate_sentiment($pdo, 24);

    $price = null;

    if (function_exists('curl_init')) {
        $ch = curl_init(BTC_PRICE_URL);

        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 10,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_SSL_VERIFYPEER => true
        ]);

        $body = curl_exec($ch);
        curl_close($ch);

        if ($body) {
            $json = json_decode($body, true);

            if (isset($json['price'])) {
                $price = (float)$json['price'];
            }
        }
    }

    $stmt = $pdo->prepare("
        INSERT INTO sentiment_history
        (
            recorded_at,
            score,
            label,
            bullish_count,
            bearish_count,
            neutral_count,
            news_count,
            btc_price,
            sentiment_1h,
            sentiment_6h,
            sentiment_24h
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");

    $stmt->execute([
        date('Y-m-d H:i:s'),
        $s24['score'],
        $s24['label'],
        $s24['bullish'],
        $s24['bearish'],
        $s24['neutral'],
        $s24['count'],
        $price,
        $s1['score'],
        $s6['score'],
        $s24['score']
    ]);

    echo "OK\n";
    echo "News stored: {$fetch['stored']}\n";
    echo "Sentiment: {$s24['score']} {$s24['label']}\n";
    echo "BTC: " . ($price ?? 'N/A') . "\n";

} catch (Throwable $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
    exit(1);
}
?>
